# Pollen Hub — Forensic Pollen Analysis

A static, responsive frontend for exploring pollen-image uploads and forensic reporting.

## Deploy on GitHub Pages

1. Create a repository named `pollen-hub` (or any repository name you prefer).
2. Upload the **contents of this folder** to the repository root. `index.html` must be at the top level, not inside another folder.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/(root)`, then save.
6. Wait for the Pages deployment to finish. The site URL is usually `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Important: AI analysis requires a backend

GitHub Pages only hosts static files. Uploading and previewing an image work in the browser, but AI analysis is intentionally not sent directly from the browser to Anthropic. Putting an API key in a public HTML file would expose it.

To enable analysis, deploy a secure backend that accepts a JSON `POST` request containing:

- `imageBase64`: base64-encoded image data
- `imageDataUrl`: image data URL including MIME type
- `context`: sample context selected by the user
- `caseRef`: optional case reference
- `prompt`: report instructions

The backend should call your AI provider using a secret stored in its environment and return either a report JSON object (with at least `speciesName`) or a provider-style `content` array containing JSON text. Set `API_ENDPOINT` near the top of the script in `index.html` to your deployed backend URL.

Do not use AI-generated pollen identification as conclusive forensic evidence. Confirm findings with qualified examination and validated methods.
